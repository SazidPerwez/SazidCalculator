let input = document.querySelector(".input-box");
let buttons = document.querySelectorAll("button");
let str = "";

const arr = Array.from(buttons);
arr.forEach(function (button) {
  button.addEventListener("click", function (el) {
    if (el.target.innerHTML == "=") {
      str = eval(str);
      input.value = str;
    } else if (el.target.innerHTML == "AC") {
      str = "";
      input.value = str;
    } else if (el.target.innerHTML == "DEL") {
      str = str.substring(0, str.length - 1);
      input.value = str;
    } else if (el.target.innerHTML == "%") {
      str = (parseFloat(str) / 100).toString();
      input.value = str;
    } else {
      str = str + el.target.innerHTML;
      input.value = str;
    }
  });
});

document.addEventListener("keydown", function (el) {
  if (el.key === "Backspace") {
    str = str.substring(0, str.length - 1);
    input.value = str;
  }
});
